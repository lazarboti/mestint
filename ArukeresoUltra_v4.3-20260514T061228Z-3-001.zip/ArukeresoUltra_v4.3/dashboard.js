document.addEventListener('DOMContentLoaded', () => {
    const grid = document.getElementById('products-grid');
    const clearBtn = document.getElementById('clear-history-btn');
    const exportAllBtn = document.getElementById('export-all-btn');
    const exportParositasBtn = document.getElementById('export-parositas-btn');
    const clearParositasBtn = document.getElementById('clear-parositas-btn');

    function getBadgeClass(decision) {
        if (!decision) return 'bg-danger';
        if (decision.includes('SKIP!')) return 'bg-danger';
        if (decision.includes('BEST')) return 'bg-success';
        if (decision.includes('NEW DIAGRAM')) return 'bg-warning';
        if (decision.includes('NEW TOP')) return 'bg-info';
        return 'bg-danger';
    }

    function calculateDecision(product) {
        let decision = "SKIP!";
        const digitalkoFound = product.digitalkoFound;
        const digitalkoPrice = product.rawDigitalkoPrice;
        const emagPrice = product.rawEmagPrice;
        const lowestAjaxPrice = product.rawLowestAjaxPrice;
        const arukeresoMinPrice = product.rawArukeresoPrice;
        const isTop = product.isTop;
        const hasFreshReview = product.hasFreshReview;

        if (digitalkoFound === true) {
            if (digitalkoPrice && emagPrice <= digitalkoPrice) decision = "BEST SOS";
            else if (lowestAjaxPrice && emagPrice < lowestAjaxPrice) decision = "BEST DIAGRAM";
            else if (arukeresoMinPrice && emagPrice < arukeresoMinPrice) decision = "BEST ÁRUKERESŐ";
        } else if (digitalkoFound === false) {
            if ((isTop || hasFreshReview) && arukeresoMinPrice && emagPrice < arukeresoMinPrice) decision = "NEW TOP";
            else if (lowestAjaxPrice && emagPrice < lowestAjaxPrice) decision = "NEW DIAGRAM";
        }
        return decision;
    }

    function renderProducts(history) {
        grid.innerHTML = '';

        if (!history || history.length === 0) {
            grid.innerHTML = `
                <div class="empty-state">
                    <h2>Nincsenek mentett termékek</h2>
                    <p>Indíts el egy árcsekkolást az eMAG oldalán!</p>
                </div>
            `;
            return;
        }

        // Reverse to show newest first
        const reversedHistory = [...history].reverse();

        reversedHistory.forEach((product, index) => {
            // Calculate Decision dynamically
            product.decision = calculateDecision(product);

            // Format eMAG UI price to match others with 'Ft'
            const displayEmagPrice = product.rawEmagPrice ? product.rawEmagPrice.toString().replace(/\B(?=(\d{3})+(?!\d))/g, " ") + " Ft" : (product.emagPrice || "N/A");

            const card = document.createElement('div');
            card.className = 'card';

            const badgeClass = getBadgeClass(product.decision);
            const imageHtml = product.imageUrl
                ? `<img src="${product.imageUrl}" alt="Product Image" class="card-image">`
                : `<div style="color: #94a3b8; font-weight: bold;">Nincs Kép</div>`;

            card.innerHTML = `
                <div class="decision-badge ${badgeClass}">
                    ${product.decision || 'N/A'}
                </div>
                <div class="card-image-wrapper">
                    ${imageHtml}
                </div>
                <div class="card-content">
                    <h3 class="card-title">
                        <a href="${product.emagUrl}" target="_blank">${product.emagName}</a>
                    </h3>
                    
                    <div class="price-grid">
                        <div class="price-item">
                            <span class="price-label">eMAG Ár</span>
                            <a href="${product.emagUrl}" target="_blank" class="price-value emag-price" style="text-decoration: none;">${displayEmagPrice}</a>
                        </div>
                        <div class="price-item">
                            <span class="price-label">Raktár Ár</span>
                            <a href="${product.digitalkoUrl || '#'}" target="_blank" class="price-value raki-price" style="text-decoration: none; ${!product.digitalkoUrl ? 'pointer-events: none; color: inherit;' : ''}">${product.digitalkoPrice}</a>
                        </div>
                        <div class="price-item">
                            <span class="price-label">Legolcsóbb Árukereső</span>
                            <a href="${product.arukeresoUrl || '#'}" target="_blank" class="price-value aru-price" style="text-decoration: none; ${!product.arukeresoUrl ? 'pointer-events: none; color: inherit;' : ''}">${product.arukeresoPrice}</a>
                        </div>
                    </div>

                    <div class="card-actions">
                        <button class="copy-btn" data-index="${history.length - 1 - index}">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg>
                            Másolás
                        </button>
                    </div>
                </div>
            `;

            grid.appendChild(card);
        });

        // Attach copy event listeners
        document.querySelectorAll('.copy-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const idx = parseInt(e.currentTarget.getAttribute('data-index'), 10);
                const p = history[idx];

                const cEmag = p.rawEmagPrice || '';
                const cAru = p.rawArukeresoPrice || '';
                const cDigitalko = (p.digitalkoFound && p.rawDigitalkoPrice) ? p.rawDigitalkoPrice : 'NINCS';
                const textToCopy = `${p.decision || 'N/A'}\t${p.emagName}\t${p.emagUrl}\t${cEmag}\t\t${cAru}\t${cDigitalko}`;

                navigator.clipboard.writeText(textToCopy).then(() => {
                    const originalHtml = btn.innerHTML;
                    btn.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg> Kész!`;
                    btn.style.backgroundColor = '#10b981';
                    btn.style.color = '#fff';

                    setTimeout(() => {
                        btn.innerHTML = originalHtml;
                        btn.style.backgroundColor = '';
                        btn.style.color = '';
                    }, 2000);
                });
            });
        });
    }

    // Initial Load
    browser.storage.local.get(['scrapedProductsHistory']).then((result) => {
        renderProducts(result.scrapedProductsHistory || []);
    });

    // Handle Clear History
    clearBtn.addEventListener('click', () => {
        if (confirm('Biztosan törölni szeretnéd az összes előzményt?')) {
            browser.storage.local.set({ scrapedProductsHistory: [] }).then(() => {
                renderProducts([]);
            });
        }
    });

    // Handle Export All
    exportAllBtn.addEventListener('click', () => {
        browser.storage.local.get(['scrapedProductsHistory']).then((result) => {
            const history = result.scrapedProductsHistory || [];
            if (history.length === 0) return;

            let fullText = '';
            history.forEach(p => {
                const decision = calculateDecision(p);
                if (!decision || decision.includes('SKIP!')) return;

                const cEmag = p.rawEmagPrice || '';
                const cAru = p.rawArukeresoPrice || '';
                const cDigitalko = (p.digitalkoFound && p.rawDigitalkoPrice) ? p.rawDigitalkoPrice : 'NINCS';
                fullText += `${decision || 'N/A'}\t${p.emagName}\t${p.emagUrl}\t${cEmag}\t\t${cAru}\t${cDigitalko}\n`;
            });

            if (fullText === '') {
                const originalText = exportAllBtn.innerText;
                exportAllBtn.innerText = 'Nincs deal!';
                exportAllBtn.style.backgroundColor = '#ef4444';
                exportAllBtn.style.borderColor = '#ef4444';

                setTimeout(() => {
                    exportAllBtn.innerText = originalText;
                    exportAllBtn.style.backgroundColor = '';
                    exportAllBtn.style.borderColor = '';
                }, 2000);
                return;
            }

            navigator.clipboard.writeText(fullText).then(() => {
                const originalText = exportAllBtn.innerText;
                exportAllBtn.innerText = 'Összes másolva!';
                exportAllBtn.style.backgroundColor = '#10b981';
                exportAllBtn.style.borderColor = '#10b981';

                setTimeout(() => {
                    exportAllBtn.innerText = originalText;
                    exportAllBtn.style.backgroundColor = '';
                    exportAllBtn.style.borderColor = '';
                }, 2000);
            });
        });
    });

    // Handle Párosítások másolása
    exportParositasBtn.addEventListener('click', () => {
        browser.storage.local.get(['parosításokHistory']).then((result) => {
            const history = result.parosításokHistory || [];
            if (history.length === 0) {
                const orig = exportParositasBtn.innerText;
                exportParositasBtn.innerText = 'Nincs párosítás!';
                exportParositasBtn.style.backgroundColor = '#ef4444';
                exportParositasBtn.style.borderColor = '#ef4444';
                exportParositasBtn.style.color = '#fff';
                setTimeout(() => {
                    exportParositasBtn.innerText = orig;
                    exportParositasBtn.style.backgroundColor = '';
                    exportParositasBtn.style.borderColor = '';
                    exportParositasBtn.style.color = '';
                }, 2000);
                return;
            }

            const text = history.map(p => `${p.brand}\t${p.productName}\temag: ${p.urlID}`).join('\n');

            navigator.clipboard.writeText(text).then(() => {
                const orig = exportParositasBtn.innerText;
                exportParositasBtn.innerText = `${history.length} db másolva!`;
                exportParositasBtn.style.backgroundColor = '#10b981';
                exportParositasBtn.style.borderColor = '#10b981';
                exportParositasBtn.style.color = '#fff';
                setTimeout(() => {
                    exportParositasBtn.innerText = orig;
                    exportParositasBtn.style.backgroundColor = '';
                    exportParositasBtn.style.borderColor = '';
                    exportParositasBtn.style.color = '';
                }, 2000);
            });
        });
    });

    // Handle Párosítások törlése
    clearParositasBtn.addEventListener('click', () => {
        if (confirm('Biztosan törölni szeretnéd az összes párosítást?')) {
            browser.storage.local.set({ parosításokHistory: [] }).then(() => {
                const orig = clearParositasBtn.innerText;
                clearParositasBtn.innerText = 'Törölve!';
                setTimeout(() => { clearParositasBtn.innerText = orig; }, 1800);
            });
        }
    });
});
