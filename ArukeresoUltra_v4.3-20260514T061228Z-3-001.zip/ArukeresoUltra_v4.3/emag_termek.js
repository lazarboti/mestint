function attemptExtraction(savedPrice) {
    const titleElement = document.querySelector('.page-title');
    const codeElement = document.querySelector('.product-code-display');

    // If we don't have a saved price, we need the priceElement to be ready
    let priceElement = null;
    if (!savedPrice) {
        priceElement = document.querySelector('[title*="kuponos kedvezménnyel csökkentett ár"]') ||
            document.querySelector('.product-new-price[data-test="main-price"]');
    }

    // Ensure all critical elements are rendered before extracting
    if (titleElement && codeElement && (savedPrice || priceElement)) {
        const pageTitle = titleElement.innerText.trim();
        const productCode = codeElement.innerText.replace(/Termékkód:/i, '').trim();

        let finalPrice = savedPrice;
        if (!finalPrice && priceElement) {
            finalPrice = priceElement.innerText.replace(/\./g, ' ').replace(/Ft/gi, '').trim();
        }

        let imageUrl = '';
        const imgMeta = document.querySelector('meta[property="og:image"]');
        if (imgMeta) {
            imageUrl = imgMeta.content;
        } else {
            const imgEl = document.querySelector('.product-gallery-image img');
            if (imgEl) imageUrl = imgEl.src;
        }

        const payload = {
            name: pageTitle,
            price: finalPrice,
            url: window.location.href,
            productCode: productCode,
            imageUrl: imageUrl,
            timestamp: Date.now()
        };

        // Save data and notify background script to close tab
        const storageKey = `emagData_${productCode}`;
        browser.storage.local.set({ [storageKey]: payload }).then(() => {
            const urlParams = new URLSearchParams(window.location.search);
            if (urlParams.get('redirect') === 'true') {
                browser.runtime.sendMessage({
                    action: 'extraction_done',
                    productCode: productCode
                });
            }
        });

        return true; // Indicates success
    }

    return false; // Elements not ready yet
}

// Fetch saved price from URL instead of storage
const urlParams = new URLSearchParams(window.location.search);
const savedPrice = urlParams.get('savedPrice') || '';

// Polling mechanism to wait for dynamic DOM rendering
if (!attemptExtraction(savedPrice)) {
    const maxRetries = 20; // 10 seconds total limit (20 * 500ms)
    let attempts = 0;

    const interval = setInterval(() => {
        attempts++;
        if (attemptExtraction(savedPrice) || attempts >= maxRetries) {
            clearInterval(interval);
        }
    }, 500);
}