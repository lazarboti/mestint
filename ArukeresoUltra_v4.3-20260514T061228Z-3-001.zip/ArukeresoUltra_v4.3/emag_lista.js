// ── State ──────────────────────────────────────────────────────────────────
let highlightSemaphore = false;

// ── Vendor-filter logic ────────────────────────────────────────────────────
// Fetches each product's detail page in the background and removes the card
// if it is NOT sold directly by eMag.
function highlightEmagProducts() {
    setTimeout(() => {
        const parser = new DOMParser();

        for (const card of document.querySelectorAll('.page-container .card-v2')) {
            (async () => {
                try {
                    const r = await fetch(card.querySelector('a').href);
                    const t = await r.text();
                    const virtualDoc = parser.parseFromString(t, 'text/html');

                    const vendorEl = virtualDoc.querySelector(
                        '.highlight-box div.product-page-pricing.product-highlight div.fs-14.fw-semibold.mt-2'
                    );
                    const vendor = vendorEl
                        ? vendorEl.innerText.toLowerCase().replaceAll(/([ \n\t])/g, '')
                        : '';

                    if (!vendor.includes('forgalmazzaa(z):emag')) {
                        card.parentElement.remove();
                    }
                } catch (err) {
                    // Silently ignore network/parse errors for individual cards
                }
            })();
        }

        highlightSemaphore = false;
    }, 2000);
}

// ── Card modifications (voucher price, hunt button, párosítás button) ──────
function applyCardModifications() {
    const cards = document.querySelectorAll('.card-v2-wrapper');

    cards.forEach(card => {
        // --- VOUCHER PRICE LOGIC ---
        if (!card.querySelector('.extension-voucher-price')) {
            // '.vcr-card-badge' = campaign badges | '.persnl-badge' = personal coupon badges (e.g. "-10% kuponnal")
            const voucherBadge = card.querySelector('.vcr-card-badge') || card.querySelector('.persnl-badge');
            if (voucherBadge) {
                const match = voucherBadge.textContent.match(/-(\d+)%/);
                if (match) {
                    const discountPercent = parseInt(match[1], 10);
                    const priceElement = card.querySelector('.product-new-price');

                    if (priceElement) {
                        const normalPrice = parseInt(priceElement.textContent.replace(/\D/g, ''), 10);
                        if (!isNaN(normalPrice)) {
                            const discountMultiplier = (100 - discountPercent) / 100;
                            const voucherPrice = Math.round(normalPrice * discountMultiplier);
                            const formattedVoucherPrice = voucherPrice.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");

                            const voucherPriceElem = document.createElement('div');
                            voucherPriceElem.className = 'extension-voucher-price';
                            voucherPriceElem.innerHTML = `👉 ${formattedVoucherPrice} <span>Ft</span>`;

                            voucherPriceElem.style.display = 'block';
                            voucherPriceElem.style.width = '100%';
                            voucherPriceElem.style.fontWeight = '900';
                            voucherPriceElem.style.color = '#ffffffff';
                            voucherPriceElem.style.background = '#fa0000ff';
                            voucherPriceElem.style.marginTop = '4px';
                            voucherPriceElem.style.marginBottom = '4px';
                            voucherPriceElem.style.paddingTop = '4px';
                            voucherPriceElem.style.paddingBottom = '4px';
                            voucherPriceElem.style.borderRadius = '4px';
                            voucherPriceElem.style.fontSize = '1.4em';

                            const pricingContainer = card.querySelector('.card-v2-pricing');
                            if (pricingContainer) {
                                if (window.getComputedStyle(pricingContainer).display.includes('flex')) {
                                    pricingContainer.style.flexWrap = 'wrap';
                                }
                                pricingContainer.appendChild(voucherPriceElem);
                            }
                        }
                    }
                }
            }
        }

        // --- HUNT BUTTON LOGIC ---
        if (!card.querySelector('.vadaszat-btn')) {
            const huntBtn = document.createElement('button');
            huntBtn.className = 'vadaszat-btn';
            huntBtn.innerText = 'Árcsekkolás';

            // Button Styling
            huntBtn.style.display = 'block';
            huntBtn.style.width = '100%';
            huntBtn.style.marginTop = '10px';
            huntBtn.style.padding = '8px';
            huntBtn.style.backgroundColor = '#358f0bff';
            huntBtn.style.color = '#fff';
            huntBtn.style.border = 'none';
            huntBtn.style.borderRadius = '4px';
            huntBtn.style.cursor = 'pointer';
            huntBtn.style.fontWeight = 'bold';
            huntBtn.style.boxShadow = '0 2px 4px rgba(0,0,0,0.1)';

            // Extract the URL from the existing anchor tag in the card
            const productLink = card.querySelector('a.js-product-url');

            if (productLink) {
                huntBtn.addEventListener('click', (e) => {
                    e.preventDefault();
                    e.stopPropagation();

                    huntBtn.innerText = 'Csekkelve';
                    huntBtn.style.backgroundColor = '#b4b630ff';

                    // Extract price from card
                    let savedPriceStr = '';
                    const voucherElem = card.querySelector('.extension-voucher-price');
                    if (voucherElem) {
                        const num = voucherElem.textContent.replace(/\D/g, '');
                        savedPriceStr = num.replace(/\B(?=(\d{3})+(?!\d))/g, " ");
                    } else {
                        const priceElement = card.querySelector('.product-new-price');
                        if (priceElement) {
                            // The integer part of the price
                            const mainPrice = priceElement.childNodes[0].textContent || priceElement.textContent;
                            const num = mainPrice.replace(/\D/g, '');
                            if (num) {
                                savedPriceStr = num.replace(/\B(?=(\d{3})+(?!\d))/g, " ");
                            }
                        }
                    }

                    // Pass the price in the URL instead of global storage to allow parallel extractions
                    let targetUrl = productLink.href;
                    if (targetUrl.includes('?')) {
                        targetUrl += '&redirect=true';
                    } else {
                        targetUrl += '?redirect=true';
                    }
                    if (savedPriceStr) {
                        targetUrl += `&savedPrice=${encodeURIComponent(savedPriceStr)}`;
                    }

                    // Send message to background script to open the URL
                    browser.runtime.sendMessage({
                        action: 'open_background_tab',
                        url: targetUrl
                    });
                });

                const pricingContainer = card.querySelector('.card-v2-pricing');
                if (pricingContainer) {
                    pricingContainer.appendChild(huntBtn);
                }
            }
        }

        // --- PÁROSÍTÁS MÁSOL BUTTON LOGIC ---
        if (!card.querySelector('.parositas-masol-btn')) {
            const cardItem = card.closest('.card-item');
            if (!cardItem) return;

            const productLink = card.querySelector('a.js-product-url');
            if (!productLink) return;

            // Extract brand and product name from data-name
            const dataName = cardItem.getAttribute('data-name') || '';
            const spaceIdx = dataName.indexOf(' ');
            const brand = spaceIdx !== -1 ? dataName.substring(0, spaceIdx) : dataName;
            const productName = spaceIdx !== -1 ? dataName.substring(spaceIdx + 1) : '';

            // Extract urlID from the href: the segment after /pd/
            const urlMatch = productLink.href.match(/\/pd\/([^/?]+)/);
            const urlID = urlMatch ? urlMatch[1] : '';

            const parosBtn = document.createElement('button');
            parosBtn.className = 'parositas-masol-btn';
            parosBtn.innerText = 'Párosítás másol';

            // Button Styling
            parosBtn.style.display = 'block';
            parosBtn.style.width = '100%';
            parosBtn.style.marginTop = '6px';
            parosBtn.style.padding = '8px';
            parosBtn.style.backgroundColor = '#0a6fc2';
            parosBtn.style.color = '#fff';
            parosBtn.style.border = 'none';
            parosBtn.style.borderRadius = '4px';
            parosBtn.style.cursor = 'pointer';
            parosBtn.style.fontWeight = 'bold';
            parosBtn.style.boxShadow = '0 2px 4px rgba(0,0,0,0.1)';

            parosBtn.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();

                const textToCopy = `${brand}\t${productName}\temag: ${urlID}`;

                // Save to local storage for bulk export from dashboard
                browser.storage.local.get(['parosításokHistory']).then((result) => {
                    const history = result.parosításokHistory || [];
                    // Avoid duplicates by urlID
                    if (!history.some(item => item.urlID === urlID)) {
                        history.push({ brand, productName, urlID });
                        browser.storage.local.set({ parosításokHistory: history });
                    }
                });

                navigator.clipboard.writeText(textToCopy).then(() => {
                    const original = parosBtn.innerText;
                    parosBtn.innerText = 'Másolva!';
                    parosBtn.style.backgroundColor = '#1a8a3a';
                    setTimeout(() => {
                        parosBtn.innerText = original;
                        parosBtn.style.backgroundColor = '#0a6fc2';
                    }, 1800);
                }).catch(() => {
                    parosBtn.innerText = 'Hiba!';
                    setTimeout(() => { parosBtn.innerText = 'Párosítás másol'; }, 1800);
                });
            });

            const pricingContainer = card.querySelector('.card-v2-pricing');
            if (pricingContainer) {
                pricingContainer.appendChild(parosBtn);
            }
        }
    });
}

// ── Init ───────────────────────────────────────────────────────────────────
function init() {
    // Single observer on document.body covers both card grid updates (pagination,
    // filters) and any other dynamic DOM changes that the existing logic needs.
    const observer = new MutationObserver(() => {
        // Synchronous card modifications (idempotent – guarded by class checks inside)
        applyCardModifications();

        // Async vendor highlighting – semaphore prevents overlapping fetch storms
        if (!highlightSemaphore) {
            highlightSemaphore = true;
            highlightEmagProducts();
        }
    });
    observer.observe(document.body, { childList: true, subtree: true });

    // Run both passes once immediately on page load
    applyCardModifications();
    highlightSemaphore = true;
    highlightEmagProducts();
}

init();