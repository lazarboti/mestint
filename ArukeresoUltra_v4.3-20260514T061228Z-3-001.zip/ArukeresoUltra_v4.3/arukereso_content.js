// --- LEGOLCSÓBB ÁR KISZÁMÍTÁSA ---
function getArukeresoMinPrice() {
    const priceDivs = document.querySelectorAll('.row-price');
    if (priceDivs.length === 0) return null;

    let minPrice = Infinity;
    priceDivs.forEach(div => {
        const numberString = div.innerText.replace(/[^0-9]/g, '');
        const price = parseInt(numberString, 10);
        if (!isNaN(price) && price < minPrice) {
            minPrice = price;
        }
    });

    return minPrice !== Infinity ? minPrice : null;
}

// --- HEADLESS SCRAPER (DASHBOARD FLOW) ---
function removeAllegroOffers() {
    const jumplinks = document.querySelectorAll('.jumplink-overlay');
    jumplinks.forEach(link => {
        const dataStr = link.getAttribute('data-akjl-tr') || '';
        if (dataStr.toLowerCase().includes('allegro')) {
            const parentOffer = link.closest('.optoffer, .product-box-container');
            if (parentOffer) {
                parentOffer.remove();
            }
        }
    });
}

async function runHeadlessScraper(productCode) {
    // --- EXACT MATCH REDIRECT LOGIC ---
    // If we're NOT on an Árukereső product page (which always has -p followed by numbers in the URL)
    // we must be on some kind of search/category list page.
    if (!window.location.href.match(/-p[0-9]+(\/|\?|$)/)) {
        const escapeRegExp = (string) => string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        const regexString = `\\b${escapeRegExp(productCode)}\\b`;
        const regex = new RegExp(regexString, 'i');
        const nameLinks = document.querySelectorAll('.name a, h2 a, a.name');

        let foundExactMatch = false;

        for (const nameLink of nameLinks) {
            if (regex.test(nameLink.innerText.trim())) {
                foundExactMatch = true;
                const container = nameLink.closest('.product-box, .product-box-container, .optoffer, .list-view, .col-lg-6');
                let targetUrl = nameLink.href;

                // If the main name link is an outgoing 'Jump.php' link, look for the real Árukereső product page link
                if (targetUrl.includes('Jump.php') && container) {
                    const allLinks = Array.from(container.querySelectorAll('a'));
                    const realProductLink = allLinks.find(a => a.href && a.href.match(/-p[0-9]+/));
                    if (realProductLink) {
                        targetUrl = realProductLink.href;
                    }
                }

                if (targetUrl) {
                    window.location.replace(targetUrl);
                    return; // Stop execution, wait for the redirected page to load
                }
            }
        }

        if (!foundExactMatch) {
            const debugDiv = document.createElement('div');
            debugDiv.style.position = 'fixed';
            debugDiv.style.top = '0';
            debugDiv.style.left = '0';
            debugDiv.style.width = '100%';
            debugDiv.style.backgroundColor = 'red';
            debugDiv.style.color = 'white';
            debugDiv.style.zIndex = '999999';
            debugDiv.style.fontSize = '24px';
            debugDiv.style.padding = '10px';
            debugDiv.style.textAlign = 'center';

            // Gather all product names found on page for debugging
            const namesFound = Array.from(nameLinks).map(a => a.innerText.trim()).slice(0, 5).join(' | ');

            debugDiv.innerHTML = `<strong>Nincs pontos találat a következőre:</strong> ${productCode} <br>
                                  <small>Regex: ${regexString}</small><br>
                                  <small>Látott nevek: ${namesFound}</small>`;
            document.body.prepend(debugDiv);
        }
    }
    // --- END EXACT MATCH REDIRECT LOGIC ---
    const emagKey = `emagData_${productCode}`;
    const rakiKey = `rakiData_${productCode}`;

    const result = await browser.storage.local.get([emagKey, rakiKey, 'scrapedProductsHistory']);
    const emagData = result[emagKey] || { name: 'N/A', url: 'N/A', price: 'N/A', imageUrl: '' };
    const rakiData = result[rakiKey] || {};

    const parsedEmag = parseInt(emagData.price.replace(/[^0-9]/g, ''), 10);
    const emagPrice = isNaN(parsedEmag) ? null : parsedEmag;

    removeAllegroOffers(); // Purge Allegro listings from DOM before calculation
    const arukeresoMinPrice = getArukeresoMinPrice();
    const isTop = !!document.querySelector('.place-wrapper');

    let lowestAjaxPrice = null;
    try {
        const urlMatch = window.location.href.match(/-p([0-9]+)/);
        if (urlMatch && urlMatch[1]) {
            const pid = urlMatch[1];
            const response = await fetch(`/Ajax.GetChartData.php?pt=p&pid=${pid}&t=normal&_=${Date.now()}`);
            if (response.ok) {
                const rawText = await response.text();
                const regex = /"label"\s*:\s*"minimum ár"[\s\S]*?"data"\s*:\s*(\[\s*\{[\s\S]*?\}\s*\])/;
                const match = rawText.match(regex);
                if (match && match[1]) {
                    const priceArray = JSON.parse(match[1]);
                    const cutoffDate = new Date('2023-01-01').getTime();
                    const filteredArray = priceArray.filter(point => point.t >= cutoffDate);
                    if (filteredArray.length > 0) {
                        lowestAjaxPrice = filteredArray.reduce((min, current) => current.y < min.y ? current : min).y;
                    }
                }
            }
        }
    } catch (e) { console.error(e); }

    let hasFreshReview = false;
    let hasReviews = !!document.querySelector('span[itemprop="reviewCount"]');
    try {
        const urlMatch = window.location.href.match(/-p([0-9]+)/);
        if (hasReviews && urlMatch && urlMatch[1]) {
            const pid = urlMatch[1];
            const formData = new URLSearchParams();
            formData.append('product', `p${pid}`);
            const res = await fetch('/Ajax.TabContent.ProductReviews.php', {
                method: 'POST',
                body: formData,
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
            });
            if (res.ok) {
                const html = await res.text();
                const parser = new DOMParser();
                const doc = parser.parseFromString(html, 'text/html');
                const firstReview = doc.querySelector('.opinion-box[itemprop="review"]');
                if (firstReview) {
                    const timeElement = firstReview.querySelector('small.hidden-xs');
                    if (timeElement && !timeElement.innerText.toLowerCase().includes('éve')) {
                        hasFreshReview = true;
                    }
                }
            }
        }
    } catch (e) { console.error(e); }

    const digitalkoFound = rakiData.digitalkoFound;
    const digitalkoPrice = rakiData.digitalkoLowestPrice;

    function stripRedirect(urlStr) {
        if (!urlStr) return '';
        try {
            const u = new URL(urlStr);
            u.searchParams.delete('redirect');
            return u.toString();
        } catch (e) { return urlStr; }
    }

    const newEntry = {
        emagName: emagData.name,
        emagUrl: stripRedirect(emagData.url),
        emagPrice: emagData.price,
        imageUrl: emagData.imageUrl || '',
        digitalkoUrl: stripRedirect(rakiData.digitalkoUrl),
        arukeresoUrl: stripRedirect(window.location.href),
        rawEmagPrice: emagPrice,
        rawDigitalkoPrice: digitalkoFound ? digitalkoPrice : null,
        rawArukeresoPrice: arukeresoMinPrice,
        rawLowestAjaxPrice: lowestAjaxPrice,
        digitalkoFound: digitalkoFound,
        digitalkoPrice: digitalkoFound && digitalkoPrice ? digitalkoPrice.toString().replace(/\B(?=(\d{3})+(?!\d))/g, " ") + " Ft" : "NINCS",
        arukeresoPrice: arukeresoMinPrice ? arukeresoMinPrice.toString().replace(/\B(?=(\d{3})+(?!\d))/g, " ") + " Ft" : "N/A",
        isTop: isTop,
        hasFreshReview: hasFreshReview,
        timestamp: Date.now()
    };

    let history = result.scrapedProductsHistory || [];

    // Deduplication: if a product with the same eMAG Name exists, update it instead of adding a new one
    // Remove the old entry and push the new one to the end so it appears at the top of the dashboard
    history = history.filter(p => p.emagName !== newEntry.emagName);
    history.push(newEntry);

    await browser.storage.local.set({ scrapedProductsHistory: history });

    // Clean up temporary keys for this product
    if (productCode) {
        await browser.storage.local.remove([emagKey, rakiKey]);
    }

    browser.runtime.sendMessage({ action: 'arukereso_extraction_done' });
}

// --- INIT ---
browser.runtime.sendMessage({ action: 'check_auto_extract' }).then((response) => {
    if (response && response.isAuto && response.productCode) {
        runHeadlessScraper(response.productCode);
    }
    // If it's manual mode, we do absolutely nothing. The script is invisible.
}).catch(err => {
    console.error('Failed to check auto extract status:', err);
});