function findLowestPriceRow() {
    // Select all rows that start with the ID "sor_"
    const rows = document.querySelectorAll('tr[id^="sor_"]');

    let lowestPrice = Infinity;
    let targetRow = null;

    rows.forEach(row => {
        // 1. Filter by Date (2023 and onwards)
        const dateCell = row.querySelector('td[id^="erk_datum_"]');
        if (!dateCell) return; // Skip if date cell is missing

        const dateString = dateCell.innerText.trim();
        const year = parseInt(dateString.substring(0, 4), 10);
        if (isNaN(year) || year < 2023) return;

        // 2. Locate Delivery Fee and Price cells
        const deliveryCell = row.querySelector('td[id^="szall_dij_"]');
        if (!deliveryCell) return;

        // The price cell immediately precedes the delivery cell
        const priceCell = deliveryCell.previousElementSibling;
        if (!priceCell) return;

        // 3. Parse values 
        // Accounting for standard local formatting, dots (.) act as thousands separators and must be removed before parsing.
        const priceText = priceCell.innerText.replace(/\./g, '').trim();
        const price = parseFloat(priceText);

        const deliveryText = deliveryCell.innerText.replace(/\./g, '').trim();
        const deliveryFee = parseFloat(deliveryText);

        if (isNaN(price)) return;

        // 4. Calculate final price
        let finalPrice = price;

        if (!isNaN(deliveryFee) && deliveryFee < 0) {
            // Adding a negative delivery fee mathematically applies the subtraction (discount)
            finalPrice += deliveryFee;
        }

        // 5. Evaluate for the lowest price
        if (finalPrice < lowestPrice) {
            lowestPrice = finalPrice;
            targetRow = row;
        }
    });

    return {
        rowElement: targetRow,
        lowestPrice: lowestPrice
    };
}

// Execution and highlighting the result for verification
const result = findLowestPriceRow();

let storagePayload = {};

if (result.rowElement) {
    console.log("Lowest recorded price found:", result.lowestPrice);
    // Highlights the identified row in the DOM visually 
    result.rowElement.style.border = "3px solid #ff0000";
    
    storagePayload = {
        digitalkoFound: true,
        digitalkoLowestPrice: result.lowestPrice,
        digitalkoUrl: window.location.href
    };
} else {
    console.log("No rows found matching the criteria.");
    
    storagePayload = {
        digitalkoFound: false,
        digitalkoUrl: window.location.href
    };
}

// Save result to storage, then notify background script
const urlParams = new URLSearchParams(window.location.search);
const productCode = urlParams.get('uksz');

if (productCode) {
    const storageKey = `rakiData_${productCode}`;
    browser.storage.local.set({ [storageKey]: storagePayload }).then(() => {
        // Notify background script if this script is running in the main tab (not an iframe)
        if (window.top === window.self) {
            // Only redirect if redirect flag is explicitly set
            if (urlParams.get('redirect') !== 'true') {
                console.log("No redirect flag set, halting automatic progression.");
                return;
            }

            browser.runtime.sendMessage({
                action: 'raki_extraction_done',
                searchQuery: productCode
            });
        }
    });
}