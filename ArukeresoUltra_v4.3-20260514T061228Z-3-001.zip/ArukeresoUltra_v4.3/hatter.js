let automatedArukeresoTabs = {};

browser.runtime.onMessage.addListener((request, sender, sendResponse) => {

    if (request.action === 'open_background_tab') {
        // Open the eMAG product page silently in the background
        browser.tabs.create({ url: request.url, active: false });
    }

    else if (request.action === 'extraction_done') {
        // Construct the Árukereső URL
        const searchQuery = encodeURIComponent(request.productCode);
        const rakiUrl = `https://www.digitalko.hu/fesh97/raktar_mod.php?uksz=${searchQuery}&order=erk_datum&desc=desc&mind&&redirect=true`;

        // Open Árukereső (active: false keeps it in the background; change to true to focus it immediately)
        browser.tabs.create({ url: rakiUrl, active: false });

        // Close the background eMAG product page that just finished extracting
        if (sender.tab && sender.tab.id) {
            browser.tabs.remove(sender.tab.id);
        }
    }

    else if (request.action === 'raki_extraction_done') {
        const arukeresoUrl = `https://www.arukereso.hu/CategorySearch.php?st=${encodeURIComponent(request.searchQuery)}&arukereso-kereses`;

        // Open Árukereső in the background and track its ID
        browser.tabs.create({ url: arukeresoUrl, active: false }).then(tab => {
            automatedArukeresoTabs[tab.id] = request.searchQuery;
        });

        // Close the background Digitalko page that just finished extracting
        if (sender.tab && sender.tab.id) {
            browser.tabs.remove(sender.tab.id);
        }
    }

    else if (request.action === 'arukereso_extraction_done') {
        // Remove tracking since we're done
        if (sender.tab && sender.tab.id) {
            delete automatedArukeresoTabs[sender.tab.id];
        }

        const dashboardUrl = browser.runtime.getURL("dashboard.html");

        browser.tabs.query({ url: dashboardUrl }).then((tabs) => {
            if (tabs.length > 0) {
                // Focus existing dashboard tab and reload it
                browser.tabs.update(tabs[0].id, { active: false });
                browser.tabs.reload(tabs[0].id);
            } else {
                // Create a new dashboard tab
                browser.tabs.create({ url: dashboardUrl, active: true });
            }
        });

        // Close the background Árukereső page
        if (sender.tab && sender.tab.id) {
            browser.tabs.remove(sender.tab.id);
        }
    }

    else if (request.action === 'check_auto_extract') {
        const pCode = sender.tab ? automatedArukeresoTabs[sender.tab.id] : null;
        if (pCode) {
            sendResponse({ isAuto: true, productCode: pCode });
        } else {
            sendResponse({ isAuto: false });
        }
        return true;
    }
});