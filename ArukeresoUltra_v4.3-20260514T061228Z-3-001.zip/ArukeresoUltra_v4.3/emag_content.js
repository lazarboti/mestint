// 1. Gomb létrehozása és formázása az eMAG oldalon
const saveBtn = document.createElement('button');
saveBtn.innerText = 'Vadászat ->';
saveBtn.style.position = 'fixed';
saveBtn.style.right = '20px';
saveBtn.style.top = '50%';
saveBtn.style.transform = 'translateY(-50%)';
saveBtn.style.zIndex = '999999';
saveBtn.style.padding = '15px 20px';
saveBtn.style.backgroundColor = '#005eb8';
saveBtn.style.color = '#fff';
saveBtn.style.border = 'none';
saveBtn.style.borderRadius = '6px';
saveBtn.style.cursor = 'pointer';
saveBtn.style.boxShadow = '0 4px 6px rgba(0,0,0,0.2)';
saveBtn.style.fontFamily = 'Arial, sans-serif';
saveBtn.style.fontSize = '16px';
saveBtn.style.fontWeight = 'bold';

document.body.appendChild(saveBtn);

// 2. Gombnyomás eseménykezelője
saveBtn.addEventListener('click', () => {
    let priceElement = document.querySelector('[title*="kuponos kedvezménnyel csökkentett ár"]');
    if (!priceElement) {
        priceElement = document.querySelector('.product-new-price[data-test="main-price"]');
    }

    const titleElement = document.querySelector('.page-title');
    const url = window.location.href;

    const pageTitle = titleElement ? titleElement.innerText.trim() : '';
    let price = 'N/A';

    if (priceElement) {
        price = priceElement.innerText.replace(/\./g, ' ').replace(/Ft/gi, '').trim();
    } else {
        console.warn('Nem található ár az eMAG oldalon.');
    }

    // --- ÚJ RÉSZ: Termékkód kinyerése ---
    let productCode = '';
    const codeElement = document.querySelector('.product-code-display');
    if (codeElement) {
        const rawText = codeElement.innerText;
        productCode = rawText.replace(/Termékkód:/i, '').trim();
    } else {
        console.warn("Nem található a termék kódja.");
    }

    if (!pageTitle) {
        alert('Nem található a termék neve, a keresés nem indítható.');
        return;
    }

    // Adatok összeállítása, benne a termékkóddal
    const payload = {
        name: pageTitle,
        price: price,
        url: url,
        productCode: productCode, // Itt adjuk át
        timestamp: Date.now()
    };

    // 3. Adatok mentése a storage-ba
    browser.storage.local.set({ emagItemData: payload }).then(() => {
        const originalText = saveBtn.innerText;
        saveBtn.innerText = 'Sikeres mentés!';
        saveBtn.style.backgroundColor = '#28a745';
        
        setTimeout(() => {
            saveBtn.innerText = originalText;
            saveBtn.style.backgroundColor = '#005eb8';
        }, 2000);

        const searchQuery = encodeURIComponent(pageTitle);
        const arukeresoUrl = `https://www.arukereso.hu/CategorySearch.php?st=${searchQuery}&arukereso-kereses`;
        
        window.open(arukeresoUrl, '_blank');

    }).catch(error => {
        console.error('Hiba az adat mentésekor:', error);
        alert('Hiba történt a mentés során.');
    });
});